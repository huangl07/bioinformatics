Statistics::RankCorrelation
==========================

Perl code to compute the Pearson and Kendall rank correlation between two vectors.
